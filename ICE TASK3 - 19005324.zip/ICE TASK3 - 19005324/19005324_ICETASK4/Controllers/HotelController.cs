using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using TodoApi.Util;

namespace TodoApi.Controllers
{
    [ApiController]
    [Route("[controller]/[action]")]
    public class HotelController : ControllerBase
    {
        private List<Hotel> hotels = HotelListUtil.hotels;

        private readonly ILogger<WeatherForecastController> _logger;

        public HotelController()
        {
            if(hotels.Count < 1)
            {
                hotels.Add(h1);
                hotels.Add(h2);
                hotels.Add(h3);
            }
        }

        [HttpGet]
        public List<Hotel> GetHotels()
        {
            return hotels;
        }
        [HttpPost]
        public List<Hotel> PostHotel(Hotel h)
        {
            hotels.Add(h);
            return hotels;
        }

        [HttpGet]
        public Hotel getOne(string s)
        {
            return hotels.Where(x => x.Name.Contains(s)).FirstOrDefault();
        }



    }
}
